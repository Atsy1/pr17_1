package com.example.prakt17

import android.content.Context
import android.content.DialogInterface
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.view.View
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
 private val APP_PREFERENCES = "mysettings"
    private val PREF_LOGIN="login"
    private val PREF_PASSWORD="password"
    private lateinit var settings:SharedPreferences
    private lateinit var login:EditText
    private lateinit var password:EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        settings=getSharedPreferences(APP_PREFERENCES, MODE_PRIVATE)
        login=findViewById(R.id.login)
        password=findViewById(R.id.password)
    }

    fun setPreference (view: View)
    {
        val message = AlertDialog.Builder(this)
        message.setTitle("Сообщение")
        message.setMessage("Сохранить данную информацию?")
        message.setPositiveButton("OK",DialogInterface.OnClickListener{dialog, which->
            val logins = login.text.toString()
            val passwords = password.text.toString()
            val prefEditor=settings.edit()
            prefEditor.putString(PREF_LOGIN,logins)
            prefEditor.putString(PREF_PASSWORD,passwords)
            prefEditor.apply()
        })
        message.setNegativeButton("Oтмена", DialogInterface.OnClickListener{dialog, which->
            val text = "Вы отменили сохранение"
            val duration = Toast.LENGTH_SHORT
           Toast.makeText(applicationContext, text , duration).show()
        })
        val dialog=message.create()
        message.show()
    }
    fun getPref (view: View)
    {
        val savelogin=settings.getString(PREF_LOGIN,"")
        login.setText(savelogin)
        val savepassword=settings.getString(PREF_PASSWORD,"")
        password.setText(savepassword)
    }
}